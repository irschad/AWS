
Open the below URL in web browser: 

http://d1davtpp7lwrdp.cloudfront.net/index.html